const form = document.querySelector("form");

form.addEventListener("submit", function () {
    alert("Calculating student's grade...");
});