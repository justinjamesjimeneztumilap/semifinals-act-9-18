<?php
$result = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $studentName = $_POST["studentName"];
    $grade1 = $_POST["grade1"];
    $grade2 = $_POST["grade2"];
    $grade3 = $_POST["grade3"];

        
    $average = ($grade1 + $grade2 + $grade3) / 3;

    if ($average >= 80) {
        $status = "Passed";
    } else {
        $status = "Failed";
    }

    $result = "
        <section class='result'>
            <h2>Student Result</h2>
            <p>Student Name: $studentName</p>
            <p>Average Grade: " . number_format($average, 2) . "</p>
            <p>Status: $status</p>
        </section>
    ";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Grade Calculator</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&family=Shrikhand&display=swap" rel="stylesheet">
    <script src="script/script.js" defer></script>

</head>
<body>
    <header>
        <h1>Student Grade Calculator</h1>
    </header>

    <main class="container">
        <h2>Enter Student Info and Grades</h2>

        <form method="POST">
            <label for="studentName">Student Name:</label>
            <input type="text" id="studentName" name="studentName" required>

            <label for="grade1">Grade 1:</label>
            <input type="number" id="grade1" name="grade1" min="0" max="100" required>

            <label for="grade2">Grade 2:</label>
            <input type="number" id="grade2" name="grade2" min="0" max="100" required>

            <label for="grade3">Grade 3:</label>
            <input type="number" id="grade3" name="grade3" min="0" max="100" required>

            <button type="submit">Calculate Grade</button>
        </form>

        <?php 
            echo $result;
         ?> 

    </main>
    
</body>
</html>